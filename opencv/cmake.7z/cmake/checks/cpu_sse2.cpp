#include <emmintrin.h>
int main() { return 0; }
